# PlayingUnderStorm
A game developed in 3 hours (for TriJam in Itch.io)

    - Programming: 3 hours
    - Design: 1 hour
    - Make assets: 1.5 hours
    - Sound implementation: 1.5h

To play this game => [Playing Under Storm](https://samuelreyesalvarez.github.io/PlayingUnderStorm/)
